async function getCurrentWeatherByCity(city) {
    const data = await fetch('http://api.weatherapi.com/v1/current.json?key=fa796e7808f64fc0bc6123445242411&q=${city}&aqi=no')
    const currentWeather = await data.json()
    console.log(currentWeather)
    return currentWeather
}

const locationInput = document.querySelector('.location-input')

const locationButton = document.querySelector('.location-button')
locationButton.addEventListener('click', () => {
    const locationInputValue = locationInput.value
    getCurrentWeatherByCity(locationInputValue)
    })

function renderCurrentWeather(iconSrc){
const currentWeatherIcon = document.createElement('img')
currentWeatherIcon.setAttribute('class', "current-weather-icon")
currentWeatherIcon.setAttribute('src', iconSrc)
}